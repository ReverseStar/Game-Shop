package app.aaman007.com.sgs;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SignUp extends AppCompatActivity {

    private EditText userr,email,password,reTypePassword;
    private Button Account;

    public static List<String> allUsers = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        this.setTitle("Sign Up");

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        userr = findViewById(R.id.userId);
        email = findViewById(R.id.emailId);
        password = findViewById(R.id.regPasswordId);
        reTypePassword = findViewById(R.id.regPassword2Id);
        Account= findViewById(R.id.CreateAccId);

        Account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user , pass , email1 , confirmPass;
                user = userr.getText().toString();
                email1 = email.getText().toString();
                pass = password.getText().toString();
                confirmPass = reTypePassword.getText().toString();

                if(user.equals("") || email1.equals("") || pass.equals("") || confirmPass.equals(""))
                    toast("Please fill all informations");
                else if(!pass.equals(confirmPass))
                    toast("Password doesn't match");
                else if(allUsers.contains(user) == false)
                {
                    allUsers.add(user);
                    login.usersID.add(new Pair<String, String>(user,pass));
                        CartView.itemsName.put(user,new ArrayList<String>());
                        CartView.itemPrice.put(user,new ArrayList<Integer>());
                    toast("Registration Successful!!");
                    finish();
                }
                else
                    toast("Username already exists");
            }
        });
    }
    public void toast(String s)
    {
        Toast.makeText(SignUp.this,s, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            this.finish();
        return super.onOptionsItemSelected(item);
    }
}
