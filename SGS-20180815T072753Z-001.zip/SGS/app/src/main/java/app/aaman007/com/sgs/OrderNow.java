package app.aaman007.com.sgs;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class OrderNow extends AppCompatActivity {

    private EditText name,phone,email,courierAddress;
    private Button confirmOrder;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_now);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Order Now");
        //getSupportActionBar().setLogo(R.drawable.ic_shopping_cart);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        name = findViewById(R.id.buyerNameId);
        phone = findViewById(R.id.buyerPhoneId);
        email = findViewById(R.id.buyerEmailId);
        courierAddress = findViewById(R.id.buyerAddressId);

        confirmOrder = findViewById(R.id.confirmId);
        confirmOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String buyerName = name.getText().toString();
                String buyerPhone = phone.getText().toString();
                String buyerEmail = email.getText().toString();
                String address = courierAddress.getText().toString();

                if(buyerEmail.equals("") || buyerName.equals("") || buyerPhone.equals("") || address.equals(""))
                    Toast.makeText(getApplicationContext(),"Please fill all",Toast.LENGTH_SHORT).show();
                else {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/email");
                    String subject = "New Order";
                    String text;
                    text = "Name : " + buyerName + "\n";
                    text += "Email : "+buyerEmail+"\n";
                    text += "Phone Number : "+buyerPhone+"\n";
                    text += "Courier Address : "+address+"\n\n";
                    text += "Ordered Items :\n";
                    for(int i=0;i<CartView.itemsName.get(login.userName).size();i++)
                        text += CartView.itemsName.get(login.userName).get(i)+"     TK."+CartView.itemPrice.get(login.userName).get(i)+"\n";
                    intent.putExtra(Intent.EXTRA_SUBJECT,subject);
                    intent.putExtra(Intent.EXTRA_TEXT,text);
                    intent.putExtra(Intent.EXTRA_EMAIL,new String[]  {"destro.mahmud@gmail.com"});
                    startActivity(Intent.createChooser(intent,"Order Using"));
                }
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            this.finish();
        return super.onOptionsItemSelected(item);
    }
}
