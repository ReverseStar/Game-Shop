package app.aaman007.com.sgs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartView extends AppCompatActivity {

    private Button button;
    private ListView listView;
    TextView textView;

    static Map< String ,List<String> > itemsName = new HashMap<>();
    static Map< String,ArrayList<Integer>> itemPrice = new HashMap<>();
    //static Map< String,ArrayList<Integer>> itemImages = new HashMap<>();
    //static Map< String,ArrayList<String>> itemDetails = new HashMap<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_view);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Cart");
        //getSupportActionBar().setLogo(R.drawable.ic_shopping_cart);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setDisplayUseLogoEnabled(true);

        listView = findViewById(R.id.cartListViewId);

        // Setting Adapter
        setAdapters();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String name = itemsName.get(login.userName).get(position).toString();
                cartDialog(name,position);
            }
        });

        setTotal();

        // Finding Button and setting listeners
        button = findViewById(R.id.buttonId);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemsName.get(login.userName).isEmpty()){
                    Toast.makeText(CartView.this,"Cart is empty",Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent = new Intent(CartView.this, OrderNow.class);
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            this.finish();
        return super.onOptionsItemSelected(item);
    }

    public void setAdapters()
    {
        ListViewAdapter adapter = new ListViewAdapter(CartView.this,itemsName.get(login.userName),itemPrice.get(login.userName));
        listView.setAdapter(adapter);
    }
    public void setTotal()
    {
        textView = findViewById(R.id.totalId);
        textView.setText("Total : "+getSum()+" Taka");
    }
    public static Integer getSum()
    {
        Integer sum = 0;
        for(int i=0;i<itemPrice.get(login.userName).size();i++)
            sum += itemPrice.get(login.userName).get(i);
        if(sum > 0)
            sum += 100;
        return sum;
    }
    // Cart Dialog
    public void cartDialog(final String name, final int position)
    {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(CartView.this);

        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setTitle("Cart");
        alertDialogBuilder.setMessage("Do you want to delete "+name+" from Cart?");
        //alertDialogBuilder.setIcon(R.drawable.alert);

        alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    itemsName.get(login.userName).remove(position);
                    itemPrice.get(login.userName).remove(position);
                    setTotal();
                    setAdapters();
                    Toast.makeText(CartView.this, name + " is deleted from Cart", Toast.LENGTH_SHORT).show();
                }catch (Exception e){

                }
            }
        });
        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
