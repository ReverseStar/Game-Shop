package app.aaman007.com.sgs;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class GameDetails extends AppCompatActivity {

    private ImageView imageView;
    private TextView textView;
    private Button addToCart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_details);

        this.setTitle("Game Details");

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle bundle = getIntent().getExtras();
        String details = bundle.getString("Details");
        final String name = bundle.getString("Name");
        final int price = bundle.getInt("Price");
        int image = bundle.getInt("Image");

        imageView = findViewById(R.id.gameImageId);
        textView = findViewById(R.id.gameDetailsId);
        addToCart = findViewById(R.id.addToCartId);

        textView.setText(details);
        imageView.setImageResource(image);

        addToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CartView.itemPrice.get(login.userName).add(price);
                CartView.itemsName.get(login.userName).add(name);
                Toast.makeText(GameDetails.this,name+" added to cart successfully!!",Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            this.finish();
        return super.onOptionsItemSelected(item);
    }
}
