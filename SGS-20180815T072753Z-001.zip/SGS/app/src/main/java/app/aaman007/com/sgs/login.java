package app.aaman007.com.sgs;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class login extends AppCompatActivity {

    private EditText editText1 , editText2;
    private Button loginButton,registerButton;
    public static ArrayList< Pair<String,String> > usersID = new ArrayList<>();
    public static final ArrayList<String> adminsID = new ArrayList<>();
    public static String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if(usersID.isEmpty()) {
            usersID.add(new Pair<String, String>("a", "a"));
            if(CartView.itemsName.get("a") == null)
            {
                CartView.itemsName.put("a",new ArrayList<String>());
                CartView.itemPrice.put("a",new ArrayList<Integer>());
            }
            usersID.add(new Pair<String, String>("admin", "admin"));
            if(CartView.itemsName.get("admin") == null)
            {
                CartView.itemsName.put("admin",new ArrayList<String>());
                CartView.itemPrice.put("admin",new ArrayList<Integer>());
            }

            SignUp.allUsers.add("admin");
            SignUp.allUsers.add("a");
        }
        if(adminsID.isEmpty())
            adminsID.add("admin");

        editText1 = findViewById(R.id.usernameId);
        editText2 = findViewById(R.id.passwordId);

        loginButton = findViewById(R.id.logInId);
        registerButton = findViewById(R.id.registerId);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(userChecker() && containsCaseInsensitive(userName,adminsID))
                    {
                        Toast.makeText(login.this, "LogIn Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(login.this, AdminPanel.class);
                        startActivity(intent);
                    }
                    else if (userChecker()) {
                        Toast.makeText(login.this, "LogIn Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(login.this, GameList.class);
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(login.this, "Username or Password is incorrect", Toast.LENGTH_SHORT).show();
                        }
                    editText2.setText("");
                }
                catch (Exception e)
                {
                    Toast.makeText(login.this,"Please enter valid username and password",Toast.LENGTH_SHORT).show();
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(login.this,SignUp.class);
                startActivity(intent);
            }
        });

    }
    private boolean userChecker()
    {
        String userInput = editText1.getText().toString();
        userName = userInput;
        String passInput = editText2.getText().toString();
        for(Pair <String,String> i : usersID)
        {
            if(i.first.equalsIgnoreCase(userInput) && i.second.equals(passInput))
                return true;
        }
        return false;
    }
    // Contains without matching case
    public boolean containsCaseInsensitive(String s, ArrayList<String> l){
        for (String string : l){
            if (string.equalsIgnoreCase(s)){
                return true;
            }
        }
        return false;
    }
}
