package app.aaman007.com.sgs;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class GameList extends AppCompatActivity {

    private static final int REQUEST_CALL = 1;
    private ListView listView;
    public static final List<String>gameName = new ArrayList<>() , gameDetail = new ArrayList<>();
    public static final ArrayList<Integer>gamePrice = new ArrayList<>() , images = new ArrayList<>();

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle mToggle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_list);

        listView = findViewById(R.id.listViewId);
        drawerLayout = findViewById(R.id.drawerLayoutId);
        mToggle = new ActionBarDrawerToggle(this,drawerLayout,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView = findViewById(R.id.navId);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId() == R.id.cartMenuId)
                {
                    drawerLayout.closeDrawers();
                    Intent intent = new Intent(getApplicationContext(),CartView.class);
                    startActivity(intent);
                }
                else if(item.getItemId() == R.id.logOutId)
                    finish();
                else if(item.getItemId() == R.id.helpMenudId)
                    makePhoneCall();
                return false;
            }

        });
        

        // Adding Games
        if(gameName.isEmpty())
            addGames();

        // Setting Adapter
        ListViewAdapter adapter = new ListViewAdapter(GameList.this,gameName,gamePrice);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(GameList.this,GameDetails.class);
                intent.putExtra("Image",images.get(position));
                intent.putExtra("Name",gameName.get(position));
                intent.putExtra("Price",gamePrice.get(position));
                intent.putExtra("Details",gameDetail.get(position));
                startActivity(intent);
            }
        });
    }
    private void makePhoneCall()
    {
        if(ContextCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
        {
            String dial = "tel:01774476393";
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
        }
        else
        {
            ActivityCompat.requestPermissions(GameList.this,new String[] {Manifest.permission.CALL_PHONE},REQUEST_CALL);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode == REQUEST_CALL)
        {
            if(grantResults.length > 0 && grantResults[0] ==PackageManager.PERMISSION_GRANTED)
            {
                makePhoneCall();
            }
            else
                Toast.makeText(getApplicationContext(),"Accress Denied",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static void addGames()
    {
        gameName.add("BattleField");
        gamePrice.add(120);
        gameDetail.add("Name : Battlefield 1\n\n" +
                "Number of DvD : 6\n\n" +
                "Price : BDT 120\n\n\n" +
                "\n" +
                "Minimum Requirement :\n\n" +
                "fmkjtioj\n\n\n" +
                "\n" +
                "Recommended Requirements :\n\n" +
                "fjtihIOEet\n\n");
        images.add(R.drawable.img1);

        gameName.add("BattleField 4");
        gamePrice.add(120);
        gameDetail.add("Name : Battlefield 4\n\n" +
                "Number of DvD : 6\n\n" +
                "Price : BDT 120\n\n\n" +
                "\n" +
                "Minimum Requirement :\n\n" +
                "fmkjtioj\n\n\n" +
                "\n" +
                "Recommended Requirements :\n\n" +
                "fjtihIOEet\n\n");
        images.add(R.drawable.img2);

        gameName.add("OutLast");
        gamePrice.add(120);
        gameDetail.add("Name : OutLast\n\n" +
                "Number of DvD : 6\n\n" +
                "Price : BDT 120\n\n\n" +
                "\n" +
                "Minimum Requirement :\n\n" +
                "fmkjtioj\n\n\n" +
                "\n" +
                "Recommended Requirements :\n\n" +
                "fjtihIOEet\n\n");
        images.add(R.drawable.img3);

        gameName.add("OutLast 2");
        gamePrice.add(120);
        gameDetail.add("Name : OutLast 2\n\n" +
                "Number of DvD : 6\n\n" +
                "Price : BDT 120\n\n\n" +
                "\n" +
                "Minimum Requirement :\n\n" +
                "fmkjtioj\n\n\n" +
                "\n" +
                "Recommended Requirements :\n\n" +
                "fjtihIOEet\n\n");
        images.add(R.drawable.img4);



    }
}
