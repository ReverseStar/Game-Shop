package app.aaman007.com.sgs;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class AdminPanel extends AppCompatActivity {

    public static final int RESULT_STORE_IMAGE = 1331;
    private EditText name , dvds , price , requirements;
    //private ImageButton gameImage;
    private Button add;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        this.setTitle("Admin Panel");

        name = findViewById(R.id.newGameNameId);
        price = findViewById(R.id.newGamePriceId);
        dvds = findViewById(R.id.newGameDVDId);
        requirements = findViewById(R.id.requirementId);
        add = findViewById(R.id.addGameId);
        //gameImage = findViewById(R.id.gImageId);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String gameName = name.getText().toString() , d = dvds.getText().toString() , p = price.getText().toString() , req = requirements.getText().toString();
                Integer gamePrice = Integer.parseInt(p);
                Integer gameDVS = Integer.parseInt(d);

                if(name.getText().toString().equals("") || price.getText().toString().equals("") ||
                        dvds.getText().toString().equals("") || requirements.getText().toString().equals(""))
                {
                    Toast.makeText(AdminPanel.this,"Please fill all!!",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(GameList.gameName.isEmpty())
                        GameList.addGames();
                    GameList.gameName.add(gameName);
                    GameList.gamePrice.add(gamePrice);
                    GameList.images.add(R.drawable.default_img);
                    GameList.gameDetail.add(
                            "Name : "+gameName+"\n\n"+
                            "Number of DVDs : "+gameDVS+"\n\n"+
                                    "Price : "+gamePrice+"\n\n"+req
                    );
                    Toast.makeText(AdminPanel.this,"Game added successfully!!",Toast.LENGTH_SHORT).show();
                    name.setText("");
                    price.setText("");
                    dvds.setText("");
                    requirements.setText("");
                }
            }
        });


/*        gameImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent,RESULT_STORE_IMAGE);
            }
        });*/
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_layout2,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.gotoAppId)
        {
            Intent intent = new Intent(AdminPanel.this,GameList.class);
            startActivity(intent);
        }
        return true;
    }

/*    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == RESULT_STORE_IMAGE && resultCode == RESULT_OK && data != null)
        {
            Uri temp = data.getData();
            gameImage.setImageURI(temp);
        }
    }*/

/*    <ImageButton
    android:id="@+id/gImageId"
    android:layout_gravity="center"
    android:layout_marginTop="20dp"
    android:layout_width="150dp"
    android:layout_height="150dp"
    android:scaleType="fitXY"
    android:src="@drawable/ic_launcher_foreground"
            />*/
}
